# laravel-docschema
Laravel simple web doc schema
new version 1.4.1